@echo off
chcp 65001 >nul
setlocal
set "RAJA_VM="
if exist "%~dp0本機版\Updates\MSI-managed.txt" goto install
if exist "%~dp0本機版" (
 echo 此處已有其他本機版，為保留角色與原檔，安裝程式已停止。
 echo 請將安裝包放在完全原始 VM 版的資料夾中。
 pause
 exit /b 1
)
for /r "%~dp0" %%F in (Win2003.vmdk) do if exist "%%~fF" if not defined RAJA_VM set "RAJA_VM=%%~fF"
if not defined RAJA_VM (
 echo 找不到 Win2003.vmdk，請將安裝包內的檔案放到原始遊戲資料夾後再執行。
 pause
 exit /b 1
)
:install
if exist "%ProgramW6432%\Microsoft SQL Server\150\Tools\Binn\SqlLocalDB.exe" goto gameinstall
echo 先安裝 Microsoft SQL LocalDB 元件，可能會出現管理員確認視窗。
msiexec.exe /i "%~dp0SqlLocalDB.msi" /passive /norestart
if errorlevel 1 (
 echo 資料庫元件安裝尚未完成。若系統要求重新啟動，請重新啟動後再執行本檔。
 pause
 exit /b 1
)
:gameinstall
echo 正在使用 Windows Installer 安裝。首次需要約 15 GB 可用空間，原始 VM 與舊存檔保留。
msiexec.exe /i "%~dp0DragonRaja.msi" RAJA_START=1 RAJA_VM="%RAJA_VM%" INSTALLDIR="%~dp0本機版" /passive /norestart /l*v "%~dp0龍族安裝記錄.log"
set "RAJA_EXIT=%ERRORLEVEL%"
if not "%RAJA_EXIT%"=="0" goto done
echo 正在初始化本機資料庫，既有帳號與角色不會重置。
"%~dp0本機版\Updates\DatabaseSetup.exe" "%~dp0本機版"
set "RAJA_EXIT=%ERRORLEVEL%"
:done
if "%RAJA_EXIT%"=="0" (echo 安裝完成，請開啟「本機版\開始遊戲.cmd」。) else (echo 安裝未完成，代碼 %RAJA_EXIT%，請保留龍族安裝記錄.log。)
pause
exit /b %RAJA_EXIT%
